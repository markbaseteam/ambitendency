---
home: true
---

# Welcome to Ambitendency's Digital Garden.

This site contains my knowledge and curated content for the Ambitendency blog/community. The content contained in this garden mainly revolves around productivity, knowledge management, and digital content creation/entrepreneurship. My goal for creating this is to hopefully pass along the knowledge I've gained in my 27 years of life, hoping that someone, somewhere, will find it helpful.